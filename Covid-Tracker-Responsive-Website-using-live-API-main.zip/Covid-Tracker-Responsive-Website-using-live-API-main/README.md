# Covid-Tracker-Responsive-Website-using-live-API
This a Covid Responsive Website made using HTML, CSS, Bootstrap, JavaScript and PHP. It fetches live cases using an API and displays it on an HTML Page. It also has a feedback form which links to Database table using PHP.
